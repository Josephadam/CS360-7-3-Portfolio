package com.example.dumke_joseph_option_2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;
    private EventDBHelper dbHelper;

    public EventAdapter(List<Event> eventList) {
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        holder.textTitle.setText(event.getTitle());
        holder.textDue.setText(event.getDue());

        // Handle delete button
        holder.buttonDelete.setOnClickListener(v -> {
            if (dbHelper == null) {
                dbHelper = new EventDBHelper(v.getContext());
            }
            dbHelper.deleteEvent(event.getId());
            eventList.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle, textDue;
        ImageButton buttonDelete;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDue = itemView.findViewById(R.id.textDue);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
