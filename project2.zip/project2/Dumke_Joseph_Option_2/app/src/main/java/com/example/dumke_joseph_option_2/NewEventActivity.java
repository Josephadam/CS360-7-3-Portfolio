package com.example.dumke_joseph_option_2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewEventActivity extends AppCompatActivity {

    EditText editTitle, editNotes;
    Switch switchRemind;
    Button buttonSave, buttonDelete;
    EventDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        dbHelper = new EventDBHelper(this);

        editTitle = findViewById(R.id.editTitle);
        editNotes = findViewById(R.id.editNotes);
        switchRemind = findViewById(R.id.switchRemind);
        buttonSave = findViewById(R.id.buttonSave);
        buttonDelete = findViewById(R.id.buttonDelete);

        buttonSave.setOnClickListener(v -> {
            String title = editTitle.getText().toString();
            String notes = editNotes.getText().toString();
            String date = "2025-10-02"; // placeholder
            String time = "10:00 AM";   // placeholder
            boolean remind = switchRemind.isChecked();

            if (title.isEmpty()) {
                Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = dbHelper.insertEvent(title, date, time, notes, remind);
            if (inserted) {
                Toast.makeText(this, "Event saved!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show();
            }
        });

        buttonDelete.setOnClickListener(v -> {
            Toast.makeText(this, "Delete not implemented yet", Toast.LENGTH_SHORT).show();
        });
    }
}
